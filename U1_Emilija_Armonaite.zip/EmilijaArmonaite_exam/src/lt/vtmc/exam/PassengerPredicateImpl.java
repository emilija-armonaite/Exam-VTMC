package lt.vtmc.exam;

public class PassengerPredicateImpl implements PassengerPredicate {

	@Override
	public boolean test(Passenger passenger) {
		return false;
	}

}
